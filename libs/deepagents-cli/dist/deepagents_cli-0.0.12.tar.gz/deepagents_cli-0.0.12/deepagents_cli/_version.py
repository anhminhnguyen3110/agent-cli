"""Version information for deepagents-cli."""

__version__ = "0.0.12"
